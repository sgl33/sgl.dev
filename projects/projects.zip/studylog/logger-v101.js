/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




const recordForm = document.getElementById('main-form');
const locationInput = document.getElementById("field-location");
const subjectInput = document.getElementById("field-subject");
const recordButton = document.getElementById("record-button");
const cancelButton = document.getElementById("cancel-button");

const timerText = document.getElementById("timer-text");
const logText = document.getElementById("text-log");
const timeText = document.getElementById("text-time");



function getDateText(dayNumber)
{
    switch(dayNumber) {
        case 0: return "Sun";
        case 1: return "Mon";
        case 2: return "Tues";
        case 3: return "Wed";
        case 4: return "Thurs";
        case 5: return "Fri";
        case 6: return "Sat";
    }
}

function hideLog()
{
    //document.getElementById("log-div").style.display = "none";
    $("#log-div").fadeOut(200);
}
function showLog()
{
    //document.getElementById("log-div").style.display = "block";
    $("#log-div").fadeIn(200);
}


function recordStart()
{
    console.log("Recording started");
    
    if(localStorage.elapsedTime === undefined)
        localStorage.elapsedTime = 0;
    
    localStorage.recording = true;
    localStorage.location = locationInput.value;
    localStorage.subject = subjectInput.value;
    
    var date = new Date();
    localStorage.startDate = date.getTime();
    
    
    if(localStorage.location === "" && localStorage.subject === "") {
        localStorage.tempLog = "[Start] " +  (date.getMonth() + 1) + "/" 
            + date.getDate() + " (" + getDateText(date.getDay()) + ") " + date.getHours() + ":" + addLeadingZero(date.getMinutes()) + "<br/>";
    }
    else {
        localStorage.tempLog = "[Start] " +  (date.getMonth() + 1) + "/" 
            + date.getDate() + " (" + getDateText(date.getDay()) + ") " + date.getHours() + ":" + addLeadingZero(date.getMinutes())
            + "<br/>[Info] Location: \"" + localStorage.location + "\" / " + " Subject: \"" + localStorage.subject + "\"<br/>";
   
    }
    
    if(localStorage.log === undefined)
        localStorage.log = "";
    
    
    
    
    
    
    alert("The Start Time was successfully recorded.\n\nFeel free to close the browser or open another tab. Data will be kept. Just don't forget to come back and stop the timer!");
    
    location.reload();
}

function recordEnd()
{
    console.log("Recording ended");
    
    localStorage.removeItem('recording');
    
    
    
    var date = new Date();
    var dateDifference = (date.getTime() - localStorage.startDate);
    var deltaMinutes = Math.ceil(dateDifference / (1000 * 60));
    
    var currentMinutesTotal = localStorage.elapsedTime;
    if(localStorage.elapsedTime === undefined)
        currentMinutesTotal = 0;
    
    console.log(localStorage.elapsedTime);
    localStorage.elapsedTime = parseInt(currentMinutesTotal) + parseInt(deltaMinutes);
    
    var currentLog = localStorage.log;
    if(currentLog === undefined || currentLog === null) {
        currentLog = "";
    }
    
    localStorage.log = currentLog + localStorage.tempLog + "[End] " +  (date.getMonth() + 1) + "/" 
            + date.getDate() + " (" + getDateText(date.getDay()) + ") " + date.getHours() 
            + ":" + addLeadingZero(date.getMinutes()) + " (" + convertMinutesToString(deltaMinutes) +")<br/>";
    
    localStorage.tempLog = "";
    
    var comment = prompt("The End Time was successfully recorded." +
            "\nYou studied for " + convertMinutesToString(deltaMinutes) + "!\n\nDo you have any comments to add?", "");
    
    currentLog = localStorage.log;
    if(comment !== "" && comment != null) {
        localStorage.log = currentLog + "[Comment] " + comment  + "<br/><br/>";
        alert("Success!");
    }
    else {
        localStorage.log = currentLog + "<br/>";
    }
        
    
    location.reload();
}

function record()
{
    if(localStorage.recording !== undefined) {
        recordEnd();
    }
    else {
        recordStart();
    }
}

function convertMinutesToString(minutes)
{
    var hours = Math.floor(minutes / 60);
    var mins = minutes % 60;
    
    return "" + hours + " hr " + mins + " min";
}

function addLeadingZero(minutes)
{
    if(minutes < 10)
        return "0" + minutes;
    else
        return minutes;
}






function askReset()
{
    let result = confirm("Are you sure you want to delete all saved data? This will also cancel the current on-going record. This cannot be undone.");
    
    if(result === true) {
        resetData();
    }
}

function resetData()
{
    localStorage.clear();
    alert("The data has been cleared.");
    location.reload();
}

function printLog()
{
    let log = localStorage.log;
    
    var elapsedTime = "<br/>Total Study Time: " + convertMinutesToString(localStorage.elapsedTime);
    
    if(log === undefined) {
        logText.innerHTML = "Your Study Log is empty. Start studying now!";
    }
    else {
        logText.innerHTML = log + localStorage.tempLog + "<br/>= End of Log =";
        timeText.innerHTML = elapsedTime;
    }
    
    
}



function testLocalStorageSave()
{
    localStorage.log = "Test Log AAAAhhhhh";
    alert("Log saved");
    location.reload();
}

function init()
{
    console.log("localStorage.recording => " + localStorage.recording);
    
    
    // Currently recording
    if(localStorage.recording !== undefined) {
        recordButton.innerHTML = "■";
        
        recordButton.style.backgroundColor = "#ff9966";
        
        
        locationInput.value = localStorage.location;
        locationInput.disabled = true;
        subjectInput.value = localStorage.subject;
        subjectInput.disabled = true;
        
        updateTimer();
        setInterval(updateTimer, 3000);
    }
    else {
        recordButton.innerHTML = "▶";
        recordButton.style.backgroundColor = "#009933";
        cancelButton.style.display = "none";
    }
    
    printLog();
}

function updateTimer()
{
    var date = new Date();
    var dateDifference = (date.getTime() - localStorage.startDate);
    var deltaMinutes = Math.ceil(dateDifference / (1000 * 60));
    timerText.innerHTML = "🕒 " + convertMinutesToString(deltaMinutes - 1);
}


function cancelRecord()
{
    let result = confirm("Are you sure you want to cancel the current record?");
    
    if(result === true) {
        
        localStorage.removeItem('recording');
        localStorage.tempLog = "";
        
        alert("The record was successfully cancelled.");
        location.reload();
    }
}

init();